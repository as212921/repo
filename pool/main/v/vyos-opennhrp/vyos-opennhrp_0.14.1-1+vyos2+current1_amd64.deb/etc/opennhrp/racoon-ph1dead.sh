#!/bin/sh

opennhrpctl cache lowerdown nbma $REMOTE_ADDR local-nbma $LOCAL_ADDR
