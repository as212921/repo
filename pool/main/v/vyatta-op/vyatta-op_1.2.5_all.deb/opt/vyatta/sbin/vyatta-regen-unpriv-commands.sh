#!/bin/bash
source /opt/vyatta/share/vyatta-op/functions/interpreter/vyatta-unpriv
vyatta_unpriv_gen_allowed
