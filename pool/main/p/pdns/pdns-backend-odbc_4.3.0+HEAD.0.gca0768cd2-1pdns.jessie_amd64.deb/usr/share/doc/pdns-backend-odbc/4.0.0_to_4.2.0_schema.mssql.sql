ALTER TABLE records DROP COLUMN change_date;
